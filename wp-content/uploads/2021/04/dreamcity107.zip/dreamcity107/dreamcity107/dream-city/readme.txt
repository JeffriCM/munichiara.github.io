/**
 * @package 	WordPress
 * @subpackage 	Dream City
 * @version 	1.0.7
 * 
 * Theme Information
 * Created by CMSMasters
 * 
 */

To update your theme please use the files list from the FILE LOGS below and substitute/add the listed files on your server with the same files in the Updates folder.

Important: after you have updated the theme, in your admin panel please proceed to
Theme Settings - Fonts and click "Save" in any tab,
then proceed to 
Theme Settings - Colors and click "Save" in any tab here.


--------------------------------------
Version 1.0.7: files operations:


	Theme Files edited:
		dream-city\comments.php
		dream-city\framework\admin\inc\config-functions.php
		dream-city\framework\admin\inc\js\wp-color-picker-alpha.js
		dream-city\framework\admin\settings\cmsmasters-theme-settings-general.php
		dream-city\framework\admin\settings\cmsmasters-theme-settings-single.php
		dream-city\framework\admin\settings\css\cmsmasters-theme-settings.css
		dream-city\framework\function\general-functions.php
		dream-city\js\jquery.script.js
		dream-city\readme.txt
		dream-city\style.css
		dream-city\theme-framework\languages\dream-city.pot
		dream-city\theme-framework\plugin-activator.php
		dream-city\theme-framework\plugins\cmsmasters-content-composer.zip
		dream-city\theme-framework\plugins\LayerSlider.zip
		dream-city\theme-framework\plugins\revslider.zip
		dream-city\theme-framework\theme-style\admin\theme-settings-defaults.php
		dream-city\theme-framework\theme-style\class\theme-widgets.php
		dream-city\theme-framework\theme-style\css\adaptive.css
		dream-city\theme-framework\theme-style\css\less\adaptive.less
		dream-city\theme-framework\theme-style\css\less\general.less
		dream-city\theme-framework\theme-style\css\less\style.less
		dream-city\theme-framework\theme-style\css\style.css
		dream-city\theme-framework\theme-style\function\template-functions-single.php
		dream-city\theme-framework\theme-style\postType\blog\post-single.php
		dream-city\theme-framework\theme-style\postType\portfolio\project-single.php
		dream-city\theme-framework\theme-style\postType\profile\profile-single.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\css\less\plugin-adaptive.less
		dream-city\tribe-events\cmsmasters-framework\theme-style\css\plugin-adaptive.css
	
	Theme Files removed:
		dream-city\js\scroll-spy.min.js
		
	Theme Files added:
		dream-city\js\scrollspy.js
		dream-city\theme-framework\plugins\envato-market.zip
		
	Proceed to wp-content\plugins\LayerSlider
	and update all files in this folder to version 6.6.1
	
	Proceed to wp-content\plugins\revslider
	and update all files in this folder to version 5.4.6.2
	
	
	
--------------------------------------
Version 1.0.6: files operations:


	Theme Files edited:
		dream-city\framework\function\general-functions.php
		dream-city\framework\function\likes.php
		dream-city\js\jquery.iLightBox.min.js
		dream-city\js\jquery.isotope.min.js
		dream-city\js\jquery.script.js
		dream-city\readme.txt
		dream-city\theme-framework\languages\dream-city.pot
		dream-city\theme-framework\plugin-activator.php
		dream-city\theme-framework\plugins\cmsmasters-content-composer.zip
		dream-city\theme-framework\plugins\cmsmasters-contact-form-builder.zip
		dream-city\theme-framework\plugins\revslider.zip
		dream-city\theme-framework\plugins\LayerSlider.zip
		dream-city\theme-framework\theme-style\css\adaptive.css
		dream-city\theme-framework\theme-style\css\less\general.less
		dream-city\theme-framework\theme-style\css\less\style.less
		dream-city\theme-framework\theme-style\css\style.css
		dream-city\theme-framework\theme-style\function\template-functions-post.php
		dream-city\theme-framework\theme-style\function\template-functions-profile.php
		dream-city\theme-framework\theme-style\function\template-functions-project.php
		dream-city\theme-framework\theme-style\function\template-functions-shortcodes.php
		dream-city\theme-framework\theme-style\function\theme-colors-primary.php
		dream-city\theme-framework\theme-style\js\jquery.theme-script.js
		dream-city\theme-framework\theme-style\postType\blog\post-default.php
		dream-city\theme-framework\theme-style\template\archive.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\css\plugin-adaptive.css

		
	Theme Files removed:
		dream-city\js\jqueryLibraries.min.js
		dream-city\js\jsLibraries.min.js
		
	Theme Files added:
		dream-city\js\cmsmasters-hover-slider.min.js
		dream-city\js\debounced-resize.min.js
		dream-city\js\easing.min.js
		dream-city\js\easy-pie-chart.min.js
		dream-city\js\modernizr.min.js
		dream-city\js\mousewheel.min.js
		dream-city\js\owlcarousel.min.js
		dream-city\js\query-loader.min.js
		dream-city\js\request-animation-frame.min.js
		dream-city\js\respond.min.js
		dream-city\js\scroll-spy.min.js
		dream-city\js\scroll-to.min.js
		dream-city\js\stellar.min.js
		dream-city\js\waypoints.min.js
		

	Proceed to wp-content\plugins\cmsmasters-content-composer
	and update all files in this folder to version 2.1.4
	
	Proceed to wp-content\plugins\cmsmasters-contact-form-builder
	and update all files in this folder to version 1.4.0
	
	Proceed to wp-content\plugins\LayerSlider
	and update all files in this folder to version 6.5.8
	
	Proceed to wp-content\plugins\revslider
	and update all files in this folder to version 5.4.5.2
	
	
	
--------------------------------------
Version 1.0.5: files operations:


	Theme Files edited:
		dream-city\framework\admin\options\cmsmasters-theme-options-post.php
		dream-city\framework\admin\options\cmsmasters-theme-options-project.php
		dream-city\framework\admin\options\cmsmasters-theme-options.php
		dream-city\framework\admin\options\js\cmsmasters-theme-options-toggle.js
		dream-city\framework\function\general-functions.php
		dream-city\js\jquery.script.js
		dream-city\readme.txt
		dream-city\single-project.php
		dream-city\style.css
		dream-city\theme-framework\languages\dream-city.pot
		dream-city\theme-framework\plugin-activator.php
		dream-city\theme-framework\plugins\cmsmasters-contact-form-builder.zip
		dream-city\theme-framework\plugins\cmsmasters-content-composer.zip
		dream-city\theme-framework\plugins\LayerSlider.zip
		dream-city\theme-framework\theme-style\class\theme-widgets.php
		dream-city\theme-framework\theme-style\css\less\style.less
		dream-city\theme-framework\theme-style\css\style.css
		dream-city\theme-framework\theme-style\function\template-functions-post.php
		dream-city\theme-framework\theme-style\function\template-functions-profile.php
		dream-city\theme-framework\theme-style\function\template-functions-project.php
		dream-city\theme-framework\theme-style\function\template-functions.php
		dream-city\theme-framework\theme-style\js\jquery.isotope.mode.js
		dream-city\theme-framework\theme-style\js\jquery.theme-script.js
		dream-city\theme-framework\theme-style\postType\blog\post-single.php
		dream-city\theme-framework\theme-style\postType\portfolio\project-puzzle.php
		dream-city\theme-framework\theme-style\postType\portfolio\project-single.php
		dream-city\theme-framework\theme-style\postType\profile\profile-single.php
		dream-city\theme-framework\theme-style\template\archive.php
		dream-city\theme-framework\theme-style\theme-functions.php
		

	Proceed to wp-content\plugins\cmsmasters-content-composer
	and update all files in this folder to version 2.1.2
	
	Proceed to wp-content\plugins\cmsmasters-contact-form-builder
	and update all files in this folder to version 1.3.9
	
	Proceed to wp-content\plugins\LayerSlider
	and update all files in this folder to version 6.5.7
	
	
	
--------------------------------------
Version 1.0.4: files operations:


	Theme Files edited:
	
		dream-city\style.css
		dream-city\readme.txt
		dream-city\theme-framework\plugin-activator.php
		dream-city\theme-framework\plugins\cmsmasters-content-composer.zip
		dream-city\theme-framework\theme-style\css\adaptive.css
		dream-city\theme-framework\theme-style\css\less\adaptive.less
		dream-city\theme-framework\theme-style\css\less\style.less
		dream-city\theme-framework\theme-style\css\style.css
		dream-city\theme-framework\theme-style\function\template-functions.php
		

	Proceed to wp-content\plugins\cmsmasters-content-composer
	and update all files in this folder to version 2.1.0
	
	
	
--------------------------------------
Version 1.0.3: files operations:


	Theme Files edited:
		dream-city\framework\admin\inc\admin-scripts.php
		dream-city\framework\admin\inc\js\admin-theme-scripts.js
		dream-city\framework\function\general-functions.php
		dream-city\functions.php
		dream-city\theme-framework\class\theme-widgets.php
		dream-city\theme-framework\function\template-functions-project.php
		dream-city\theme-framework\function\template-functions-shortcodes.php
		dream-city\theme-framework\postType\posts-slider\slider-project.php
		dream-city\tribe-events\modules\meta\details.php
		dream-city\tribe-events\modules\meta\organizer.php
		dream-city\tribe-events\modules\meta\venue.php
		dream-city\tribe-events\pro\single-venue.php
		dream-city\archive.php
		dream-city\author.php
		dream-city\footer.php
		dream-city\framework\admin\settings\cmsmasters-theme-settings-demo.php
		dream-city\framework\admin\settings\cmsmasters-theme-settings-general.php
		dream-city\framework\admin\settings\cmsmasters-theme-settings.php
		dream-city\framework\admin\settings\css\cmsmasters-theme-settings-rtl.css
		dream-city\framework\admin\settings\css\cmsmasters-theme-settings.css
		dream-city\framework\admin\settings\inc\cmsmasters-helper-functions.php
		dream-city\framework\admin\settings\js\cmsmasters-theme-settings.js
		dream-city\header.php
		dream-city\index.php
		dream-city\search.php
		dream-city\single-profile.php
		dream-city\single-project.php
		dream-city\single.php
		dream-city\style.css
		dream-city\theme-framework\admin\plugin-activator.php
		dream-city\theme-framework\admin\theme-settings-defaults.php
		dream-city\theme-framework\cmsmasters-c-c\cmsmasters-c-c-theme-functions.php
		dream-city\theme-framework\cmsmasters-c-c\shortcodes\cmsmasters-posts-slider.php
		dream-city\theme-framework\css\less\style.less
		dream-city\theme-framework\function\template-functions-single.php
		dream-city\theme-framework\template\footer.php
		dream-city\theme-framework\theme-functions.php
		dream-city\instagram-feed\cmsmasters-framework\cmsmasters-c-c\cmsmasters-c-c-plugin-functions.php
		dream-city\instagram-feed\cmsmasters-plugin-functions.php
		dream-city\tribe-events\cmsmasters-framework\css\less\plugin-adaptive.less
		dream-city\tribe-events\cmsmasters-framework\css\less\plugin-style.less
		dream-city\tribe-events\cmsmasters-plugin-functions.php
		dream-city\tribe-events\day\single-event.php
		dream-city\tribe-events\default-template.php
		dream-city\tribe-events\list\single-event.php
		dream-city\tribe-events\modules\bar.php
		dream-city\tribe-events\modules\meta.php
		dream-city\tribe-events\month\single-event.php
		dream-city\tribe-events\month\tooltip.php
		dream-city\tribe-events\pro\map\single-event.php
		dream-city\tribe-events\pro\modules\meta\additional-fields.php
		dream-city\tribe-events\pro\photo\content.php
		dream-city\tribe-events\pro\photo\single-event.php
		dream-city\tribe-events\pro\related-events.php
		dream-city\tribe-events\pro\single-organizer.php
		dream-city\tribe-events\pro\week\single-event.php
		dream-city\tribe-events\pro\week\tooltip.php
		dream-city\tribe-events\pro\widgets\list-widget.php
		dream-city\tribe-events\pro\widgets\modules\single-event.php
		dream-city\tribe-events\pro\widgets\this-week\single-event.php
		dream-city\tribe-events\pro\widgets\venue-widget.php
		dream-city\tribe-events\single-event.php
		dream-city\tribe-events\widgets\list-widget.php
		dream-city\theme-framework\theme-style\admin\plugin-activator.php
		dream-city\theme-framework\theme-style\admin\theme-settings-defaults.php
		dream-city\theme-framework\theme-style\cmsmasters-c-c\cmsmasters-c-c-theme-functions.php
		dream-city\theme-framework\theme-style\function\template-functions-single.php
		dream-city\theme-framework\theme-style\theme-functions.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\css\less\plugin-adaptive.less
		dream-city\tribe-events\cmsmasters-framework\theme-style\css\less\plugin-style.less
		dream-city\framework\admin\inc\config-functions.php
		dream-city\js\jqueryLibraries.min.js
		dream-city\theme-framework\theme-style\css\less\style.less
		dream-city\rtl.css
		dream-city\theme-framework\theme-style\css\style.css
		dream-city\tribe-events\cmsmasters-framework\theme-style\css\plugin-adaptive.css
		dream-city\theme-framework\theme-style\css\rtl.css
		dream-city\404.php
		dream-city\page.php
		dream-city\sitemap.php
		dream-city\theme-framework\theme-style\function\template-functions.php
		dream-city\theme-framework\theme-style\postType\blog\post-single.php
		dream-city\theme-framework\theme-style\postType\portfolio\project-single.php
		dream-city\theme-framework\theme-style\postType\profile\profile-single.php
		dream-city\theme-framework\theme-style\function\theme-colors-primary.php
		dream-city\framework\function\breadcrumbs.php
		dream-city\js\jquery.isotope.min.js
		dream-city\theme-framework\plugin-activator.php
		dream-city\theme-framework\theme-style\css\adaptive.css
		dream-city\theme-framework\theme-style\css\less\adaptive.less
		dream-city\theme-framework\theme-style\js\jquery.isotope.mode.js
		dream-city\theme-framework\theme-style\js\jquery.theme-script.js
		dream-city\comments.php
		dream-city\framework\admin\options\cmsmasters-theme-options-post.php
		dream-city\framework\admin\settings\cmsmasters-theme-settings-element.php
		dream-city\framework\admin\settings\cmsmasters-theme-settings-single.php
		dream-city\readme.txt
		dream-city\theme-framework\languages\dream-city.pot
		dream-city\theme-framework\plugins\cmsmasters-contact-form-builder.zip
		dream-city\theme-framework\plugins\cmsmasters-content-composer.zip
		dream-city\theme-framework\plugins\cmsmasters-mega-menu.zip
		dream-city\theme-framework\plugins\LayerSlider.zip
		dream-city\theme-framework\plugins\revslider.zip

	
	
	Theme Files removed:
		dream-city\rtl.css
		dream-city\theme-framework\theme-style\languages\dream-city.pot
		dream-city\searchform.php
		dream-city\css\jquery.isotope.css
	
	Theme Files added:
		dream-city\theme-framework\theme-style\template\404.php
		dream-city\theme-framework\theme-style\css\rtl.css
		dream-city\framework\function\theme-categories-icon.php
		dream-city\theme-framework\css\style.css
		dream-city\tribe-events\cmsmasters-framework\templates\day\single-event.php
		dream-city\tribe-events\cmsmasters-framework\templates\default-template.php
		dream-city\tribe-events\cmsmasters-framework\templates\list\single-event.php
		dream-city\tribe-events\cmsmasters-framework\templates\modules\bar.php
		dream-city\tribe-events\cmsmasters-framework\templates\modules\meta.php
		dream-city\tribe-events\cmsmasters-framework\templates\modules\meta\details.php
		dream-city\tribe-events\cmsmasters-framework\templates\modules\meta\organizer.php
		dream-city\tribe-events\cmsmasters-framework\templates\modules\meta\venue.php
		dream-city\tribe-events\cmsmasters-framework\templates\month\single-event.php
		dream-city\tribe-events\cmsmasters-framework\templates\month\tooltip.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\map\single-event.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\modules\meta\additional-fields.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\photo\content.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\photo\single-event.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\related-events.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\single-organizer.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\single-venue.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\week\single-event.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\week\tooltip.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\widgets\list-widget.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\widgets\modules\single-event.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\widgets\this-week\single-event.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\widgets\venue-widget.php
		dream-city\tribe-events\cmsmasters-framework\templates\single-event.php
		dream-city\tribe-events\cmsmasters-framework\templates\widgets\list-widget.php
	
	Theme Files replaced:

	From :
		dream-city\css\styles\dream-city.css
		dream-city\tribe-events\cmsmasters-plugin-functions.php
		dream-city\tribe-events\cmsmasters-framework\admin\plugin-settings.php
		dream-city\tribe-events\cmsmasters-framework\css\less\plugin-adaptive.less
		dream-city\tribe-events\cmsmasters-framework\css\less\plugin-style.less
		dream-city\tribe-events\cmsmasters-framework\css\plugin-adaptive.css
		dream-city\tribe-events\cmsmasters-framework\css\plugin-rtl.css
		dream-city\tribe-events\cmsmasters-framework\css\plugin-style.css
		dream-city\tribe-events\cmsmasters-framework\function\plugin-colors.php
		dream-city\tribe-events\cmsmasters-framework\function\plugin-fonts.php
		dream-city\tribe-events\cmsmasters-framework\templates\day\single-event.php
		dream-city\tribe-events\cmsmasters-framework\templates\default-template.php
		dream-city\tribe-events\cmsmasters-framework\templates\list\single-event.php
		dream-city\tribe-events\cmsmasters-framework\templates\modules\bar.php
		dream-city\tribe-events\cmsmasters-framework\templates\modules\meta.php
		dream-city\tribe-events\cmsmasters-framework\templates\modules\meta\details.php
		dream-city\tribe-events\cmsmasters-framework\templates\modules\meta\organizer.php
		dream-city\tribe-events\cmsmasters-framework\templates\modules\meta\venue.php
		dream-city\tribe-events\cmsmasters-framework\templates\month\single-event.php
		dream-city\tribe-events\cmsmasters-framework\templates\month\tooltip.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\map\single-event.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\modules\meta\additional-fields.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\photo\content.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\photo\single-event.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\related-events.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\single-organizer.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\single-venue.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\week\single-event.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\week\tooltip.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\widgets\list-widget.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\widgets\modules\single-event.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\widgets\this-week\single-event.php
		dream-city\tribe-events\cmsmasters-framework\templates\pro\widgets\venue-widget.php
		dream-city\tribe-events\cmsmasters-framework\templates\single-event.php
		dream-city\tribe-events\cmsmasters-framework\templates\widgets\list-widget.php
		themes\dream-city\theme-framework\admin\fonts\config-custom.json
		themes\dream-city\theme-framework\admin\js\theme-settings-toggle.js
		themes\dream-city\theme-framework\admin\plugin-activator.php
		themes\dream-city\theme-framework\admin\plugins\cmsmasters-contact-form-builder.zip
		themes\dream-city\theme-framework\admin\plugins\cmsmasters-content-composer.zip
		themes\dream-city\theme-framework\admin\plugins\cmsmasters-mega-menu.zip
		themes\dream-city\theme-framework\admin\plugins\LayerSlider.zip
		themes\dream-city\theme-framework\admin\plugins\revslider.zip
		themes\dream-city\theme-framework\admin\theme-options.php
		themes\dream-city\theme-framework\admin\theme-settings-defaults.php
		themes\dream-city\theme-framework\admin\theme-settings.php
		themes\dream-city\theme-framework\class\theme-widgets.php
		themes\dream-city\theme-framework\cmsmasters-c-c\cmsmasters-c-c-theme-functions.php
		themes\dream-city\theme-framework\cmsmasters-c-c\cmsmasters-c-c-theme-shortcodes.php
		themes\dream-city\theme-framework\cmsmasters-c-c\js\cmsmasters-c-c-theme-extend.js
		themes\dream-city\theme-framework\cmsmasters-c-c\shortcodes\cmsmasters-clients.php
		themes\dream-city\theme-framework\cmsmasters-c-c\shortcodes\cmsmasters-counter.php
		themes\dream-city\theme-framework\cmsmasters-c-c\shortcodes\cmsmasters-posts-slider.php
		themes\dream-city\theme-framework\cmsmasters-c-c\shortcodes\cmsmasters-pricing-table-item.php
		themes\dream-city\theme-framework\cmsmasters-c-c\shortcodes\cmsmasters-stat.php
		themes\dream-city\theme-framework\cmsmasters-c-c\shortcodes\cmsmasters-tab.php
		themes\dream-city\theme-framework\cmsmasters-c-c\shortcodes\cmsmasters-twitter.php
		themes\dream-city\theme-framework\css\adaptive.css
		themes\dream-city\theme-framework\css\fontello-custom.css
		themes\dream-city\theme-framework\css\fonts\fontello-custom.eot
		themes\dream-city\theme-framework\css\fonts\fontello-custom.svg
		themes\dream-city\theme-framework\css\fonts\fontello-custom.ttf
		themes\dream-city\theme-framework\css\fonts\fontello-custom.woff
		themes\dream-city\theme-framework\css\less\adaptive.less
		themes\dream-city\theme-framework\css\less\general.less
		themes\dream-city\theme-framework\css\less\style.less
		themes\dream-city\theme-framework\css\retina.css
		themes\dream-city\theme-framework\css\style.css
		themes\dream-city\theme-framework\css\styles\dream-city.css
		themes\dream-city\theme-framework\function\single-comment.php
		themes\dream-city\theme-framework\function\template-functions-post.php
		themes\dream-city\theme-framework\function\template-functions-profile.php
		themes\dream-city\theme-framework\function\template-functions-project.php
		themes\dream-city\theme-framework\function\template-functions-shortcodes.php
		themes\dream-city\theme-framework\function\template-functions-single.php
		themes\dream-city\theme-framework\function\template-functions.php
		themes\dream-city\theme-framework\function\theme-colors-primary.php
		themes\dream-city\theme-framework\function\theme-colors-secondary.php
		themes\dream-city\theme-framework\function\theme-fonts.php
		themes\dream-city\theme-framework\img\logo.png
		themes\dream-city\theme-framework\img\logo_footer.png
		themes\dream-city\theme-framework\img\logo_footer_retina.png
		themes\dream-city\theme-framework\img\logo_retina.png
		themes\dream-city\theme-framework\js\jquery.isotope.mode.js
		themes\dream-city\theme-framework\js\jquery.theme-script.js
		themes\dream-city\theme-framework\languages\dream-city.pot
		themes\dream-city\theme-framework\postType\blog\post-default.php
		themes\dream-city\theme-framework\postType\blog\post-masonry.php
		themes\dream-city\theme-framework\postType\blog\post-single.php
		themes\dream-city\theme-framework\postType\blog\post-timeline.php
		themes\dream-city\theme-framework\postType\portfolio\project-grid.php
		themes\dream-city\theme-framework\postType\portfolio\project-puzzle.php
		themes\dream-city\theme-framework\postType\portfolio\project-single.php
		themes\dream-city\theme-framework\postType\posts-slider\slider-post.php
		themes\dream-city\theme-framework\postType\posts-slider\slider-project.php
		themes\dream-city\theme-framework\postType\profile\profile-horizontal.php
		themes\dream-city\theme-framework\postType\profile\profile-single.php
		themes\dream-city\theme-framework\postType\profile\profile-vertical.php
		themes\dream-city\theme-framework\postType\quote\quote-grid.php
		themes\dream-city\theme-framework\postType\quote\quote-slider.php
		themes\dream-city\theme-framework\template\archive.php
		themes\dream-city\theme-framework\template\footer.php
		themes\dream-city\theme-framework\template\header-bot.php
		themes\dream-city\theme-framework\template\header-mid.php
		themes\dream-city\theme-framework\template\header-top.php
		themes\dream-city\theme-framework\theme-functions.php
		dream-city\instagram-feed\cmsmasters-framework\cmsmasters-c-c\cmsmasters-c-c-plugin-functions.php
		dream-city\instagram-feed\cmsmasters-framework\cmsmasters-c-c\cmsmasters-c-c-plugin-shortcodes.php
		dream-city\instagram-feed\cmsmasters-framework\cmsmasters-c-c\js\cmsmasters-c-c-plugin-extend.js
		dream-city\instagram-feed\cmsmasters-plugin-functions.php
		dream-city\theme-framework\theme-style\admin\plugin-activator.php
		dream-city\theme-framework\theme-style\admin\plugins\cmsmasters-contact-form-builder.zip
		dream-city\theme-framework\theme-style\admin\plugins\cmsmasters-content-composer.zip
		dream-city\theme-framework\theme-style\admin\plugins\cmsmasters-mega-menu.zip
		dream-city\theme-framework\theme-style\admin\plugins\LayerSlider.zip
		dream-city\theme-framework\theme-style\admin\plugins\revslider.zip
	
	To :
		dream-city\theme-framework\css\styles\dream-city.css
		dream-city\tribe-events\cmsmasters-framework\theme-style\admin\plugin-settings.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\cmsmasters-plugin-functions.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\css\less\plugin-adaptive.less
		dream-city\tribe-events\cmsmasters-framework\theme-style\css\less\plugin-style.less
		dream-city\tribe-events\cmsmasters-framework\theme-style\css\plugin-adaptive.css
		dream-city\tribe-events\cmsmasters-framework\theme-style\css\plugin-rtl.css
		dream-city\tribe-events\cmsmasters-framework\theme-style\css\plugin-style.css
		dream-city\tribe-events\cmsmasters-framework\theme-style\function\plugin-colors.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\function\plugin-fonts.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\day\single-event.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\default-template.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\list\single-event.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\modules\bar.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\modules\meta.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\modules\meta\details.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\modules\meta\organizer.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\modules\meta\venue.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\month\single-event.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\month\tooltip.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\pro\map\single-event.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\pro\modules\meta\additional-fields.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\pro\photo\content.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\pro\photo\single-event.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\pro\related-events.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\pro\single-organizer.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\pro\single-venue.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\pro\week\single-event.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\pro\week\tooltip.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\pro\widgets\list-widget.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\pro\widgets\modules\single-event.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\pro\widgets\this-week\single-event.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\pro\widgets\venue-widget.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\single-event.php
		dream-city\tribe-events\cmsmasters-framework\theme-style\templates\widgets\list-widget.php
		themes\dream-city\theme-framework\theme-style\admin\fonts\config-custom.json
		themes\dream-city\theme-framework\theme-style\admin\js\theme-settings-toggle.js
		themes\dream-city\theme-framework\theme-style\admin\plugin-activator.php
		themes\dream-city\theme-framework\theme-style\admin\plugins\cmsmasters-contact-form-builder.zip
		themes\dream-city\theme-framework\theme-style\admin\plugins\cmsmasters-content-composer.zip
		themes\dream-city\theme-framework\theme-style\admin\plugins\cmsmasters-mega-menu.zip
		themes\dream-city\theme-framework\theme-style\admin\plugins\LayerSlider.zip
		themes\dream-city\theme-framework\theme-style\admin\plugins\revslider.zip
		themes\dream-city\theme-framework\theme-style\admin\theme-options.php
		themes\dream-city\theme-framework\theme-style\admin\theme-settings-defaults.php
		themes\dream-city\theme-framework\theme-style\admin\theme-settings.php
		themes\dream-city\theme-framework\theme-style\class\theme-widgets.php
		themes\dream-city\theme-framework\theme-style\cmsmasters-c-c\cmsmasters-c-c-theme-functions.php
		themes\dream-city\theme-framework\theme-style\cmsmasters-c-c\cmsmasters-c-c-theme-shortcodes.php
		themes\dream-city\theme-framework\theme-style\cmsmasters-c-c\js\cmsmasters-c-c-theme-extend.js
		themes\dream-city\theme-framework\theme-style\cmsmasters-c-c\shortcodes\cmsmasters-clients.php
		themes\dream-city\theme-framework\theme-style\cmsmasters-c-c\shortcodes\cmsmasters-counter.php
		themes\dream-city\theme-framework\theme-style\cmsmasters-c-c\shortcodes\cmsmasters-posts-slider.php
		themes\dream-city\theme-framework\theme-style\cmsmasters-c-c\shortcodes\cmsmasters-pricing-table-item.php
		themes\dream-city\theme-framework\theme-style\cmsmasters-c-c\shortcodes\cmsmasters-stat.php
		themes\dream-city\theme-framework\theme-style\cmsmasters-c-c\shortcodes\cmsmasters-tab.php
		themes\dream-city\theme-framework\theme-style\cmsmasters-c-c\shortcodes\cmsmasters-twitter.php
		themes\dream-city\theme-framework\theme-style\css\adaptive.css
		themes\dream-city\theme-framework\theme-style\css\fontello-custom.css
		themes\dream-city\theme-framework\theme-style\css\fonts\fontello-custom.eot
		themes\dream-city\theme-framework\theme-style\css\fonts\fontello-custom.svg
		themes\dream-city\theme-framework\theme-style\css\fonts\fontello-custom.ttf
		themes\dream-city\theme-framework\theme-style\css\fonts\fontello-custom.woff
		themes\dream-city\theme-framework\theme-style\css\less\adaptive.less
		themes\dream-city\theme-framework\theme-style\css\less\general.less
		themes\dream-city\theme-framework\theme-style\css\less\style.less
		themes\dream-city\theme-framework\theme-style\css\retina.css
		themes\dream-city\theme-framework\theme-style\css\style.css
		themes\dream-city\theme-framework\theme-style\css\styles\dream-city.css
		themes\dream-city\theme-framework\theme-style\function\single-comment.php
		themes\dream-city\theme-framework\theme-style\function\template-functions-post.php
		themes\dream-city\theme-framework\theme-style\function\template-functions-profile.php
		themes\dream-city\theme-framework\theme-style\function\template-functions-project.php
		themes\dream-city\theme-framework\theme-style\function\template-functions-shortcodes.php
		themes\dream-city\theme-framework\theme-style\function\template-functions-single.php
		themes\dream-city\theme-framework\theme-style\function\template-functions.php
		themes\dream-city\theme-framework\theme-style\function\theme-colors-primary.php
		themes\dream-city\theme-framework\theme-style\function\theme-colors-secondary.php
		themes\dream-city\theme-framework\theme-style\function\theme-fonts.php
		themes\dream-city\theme-framework\theme-style\img\logo.png
		themes\dream-city\theme-framework\theme-style\img\logo_footer.png
		themes\dream-city\theme-framework\theme-style\img\logo_footer_retina.png
		themes\dream-city\theme-framework\theme-style\img\logo_retina.png
		themes\dream-city\theme-framework\theme-style\js\jquery.isotope.mode.js
		themes\dream-city\theme-framework\theme-style\js\jquery.theme-script.js
		themes\dream-city\theme-framework\theme-style\languages\dream-city.pot
		themes\dream-city\theme-framework\theme-style\postType\blog\post-default.php
		themes\dream-city\theme-framework\theme-style\postType\blog\post-masonry.php
		themes\dream-city\theme-framework\theme-style\postType\blog\post-single.php
		themes\dream-city\theme-framework\theme-style\postType\blog\post-timeline.php
		themes\dream-city\theme-framework\theme-style\postType\portfolio\project-grid.php
		themes\dream-city\theme-framework\theme-style\postType\portfolio\project-puzzle.php
		themes\dream-city\theme-framework\theme-style\postType\portfolio\project-single.php
		themes\dream-city\theme-framework\theme-style\postType\posts-slider\slider-post.php
		themes\dream-city\theme-framework\theme-style\postType\posts-slider\slider-project.php
		themes\dream-city\theme-framework\theme-style\postType\profile\profile-horizontal.php
		themes\dream-city\theme-framework\theme-style\postType\profile\profile-single.php
		themes\dream-city\theme-framework\theme-style\postType\profile\profile-vertical.php
		themes\dream-city\theme-framework\theme-style\postType\quote\quote-grid.php
		themes\dream-city\theme-framework\theme-style\postType\quote\quote-slider.php
		themes\dream-city\theme-framework\theme-style\template\archive.php
		themes\dream-city\theme-framework\theme-style\template\footer.php
		themes\dream-city\theme-framework\theme-style\template\header-bot.php
		themes\dream-city\theme-framework\theme-style\template\header-mid.php
		themes\dream-city\theme-framework\theme-style\template\header-top.php
		themes\dream-city\theme-framework\theme-style\theme-functions.php
		dream-city\instagram-feed\cmsmasters-framework\theme-style\cmsmasters-c-c\cmsmasters-c-c-plugin-functions.php
		dream-city\instagram-feed\cmsmasters-framework\theme-style\cmsmasters-c-c\cmsmasters-c-c-plugin-shortcodes.php
		dream-city\instagram-feed\cmsmasters-framework\theme-style\cmsmasters-c-c\js\cmsmasters-c-c-plugin-extend.js
		dream-city\instagram-feed\cmsmasters-framework\theme-style\cmsmasters-plugin-functions.php
		dream-city\theme-framework\plugin-activator.php
		dream-city\theme-framework\plugins\cmsmasters-contact-form-builder.zip
		dream-city\theme-framework\plugins\cmsmasters-content-composer.zip
		dream-city\theme-framework\plugins\cmsmasters-mega-menu.zip
		dream-city\theme-framework\plugins\LayerSlider.zip
		dream-city\theme-framework\plugins\revslider.zip
		
	
	Proceed to wp-content\plugins\cmsmasters-content-composer
	and update all files in this folder to version 2.0.9

	Proceed to wp-content\plugins\LayerSlider
	and update all files in this folder to version 6.5.1

	Proceed to wp-content\plugins\revslider
	and update all files in this folder to version 5.4.5.1
	
	
	
--------------------------------------
Version 1.0.2: files operations:


	Theme Files edited:
	
		dream-city\comments.php
		dream-city\footer.php
		dream-city\framework\admin\options\cmsmasters-theme-options-other.php
		dream-city\framework\admin\settings\inc\cmsmasters-helper-functions.php
		dream-city\framework\class\Browser.php
		dream-city\framework\function\breadcrumbs.php
		dream-city\framework\function\general-functions.php
		dream-city\framework\function\pagination.php
		dream-city\functions.php
		dream-city\js\jquery.iLightBox.min.js
		dream-city\js\jqueryLibraries.min.js
		dream-city\single-project.php
		dream-city\style.css
		dream-city\theme-framework\admin\plugin-activator.php
		dream-city\theme-framework\admin\plugins\cmsmasters-content-composer.zip
		dream-city\theme-framework\admin\plugins\LayerSlider.zip
		dream-city\theme-framework\admin\plugins\revslider.zip
		dream-city\theme-framework\class\theme-widgets.php
		dream-city\theme-framework\css\adaptive.css
		dream-city\theme-framework\css\less\adaptive.less
		dream-city\theme-framework\css\less\style.less
		dream-city\theme-framework\function\template-functions-profile.php
		dream-city\theme-framework\function\template-functions-single.php
		dream-city\theme-framework\function\template-functions.php
		dream-city\theme-framework\js\jquery.theme-script.js
		dream-city\theme-framework\languages\dream-city.pot
		dream-city\theme-framework\postType\quote\quote-grid.php
		dream-city\theme-framework\postType\quote\quote-slider.php
		dream-city\theme-framework\template\footer.php
		dream-city\theme-framework\template\header-bot.php
		dream-city\theme-framework\template\header-mid.php
		dream-city\theme-framework\template\header-top.php
		dream-city\tribe-events\cmsmasters-framework\css\less\plugin-style.less
		dream-city\tribe-events\cmsmasters-framework\css\plugin-style.css
		dream-city\tribe-events\modules\meta\organizer.php
		dream-city\tribe-events\pro\single-venue.php
		dream-city\tribe-events\single-event.php
		dream-city\tribe-events\modules\meta\venue.php
		dream-city\readme.txt
		
		
	Theme Files removed:
	
		dream-city\framework\class\OAuth.php
		dream-city\framework\class\twitteroauth.php
		
		

	Proceed to wp-content\plugins\cmsmasters-content-composer
	and update all files in this folder to version 2.0.6
	
	Proceed to wp-content\plugins\LayerSlider
	and update all files in this folder to version 6.3.0
	
	Proceed to wp-content\plugins\revslider
	and update all files in this folder to version 5.4.1
	
	
	
--------------------------------------
Version 1.0.1: files operations:


	Theme Files edited:
	
		dream-city\functions.php
		dream-city\js\jquery.script.js
		dream-city\readme.txt
		dream-city\style.css
		dream-city\theme-framework\admin\plugin-activator.php
		dream-city\theme-framework\admin\plugins\cmsmasters-content-composer.zip
		dream-city\theme-framework\admin\plugins\LayerSlider.zip
		dream-city\theme-framework\css\less\style.less
		dream-city\theme-framework\function\template-functions-profile.php
		dream-city\theme-framework\js\jquery.isotope.mode.js
		dream-city\theme-framework\postType\profile\profile-horizontal.php
		dream-city\theme-framework\postType\profile\profile-single.php
		dream-city\theme-framework\postType\profile\profile-vertical.php
		dream-city\theme-framework\theme-functions.php
		dream-city\tribe-events\cmsmasters-framework\function\plugin-fonts.php
		dream-city\tribe-events\widgets\list-widget.php
		
		
	Theme Files removed:
	
		dream-city\framework\class\widgets.php
		dream-city\single-event-schedule.php
		
		

	Proceed to wp-content\plugins\cmsmasters-content-composer
	and update all files in this folder to version 2.0.2
	
	Proceed to wp-content\plugins\LayerSlider
	and update all files in this folder to version 6.1.6
	
	
	
--------------------------------------
Version 1.0: Release!

