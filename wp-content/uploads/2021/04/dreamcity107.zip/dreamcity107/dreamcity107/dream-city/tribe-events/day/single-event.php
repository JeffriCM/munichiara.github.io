<?php
/**
 * Day View Single Event
 * This file contains one event in the day view
 *
 * Override this template in your own theme by creating a file at [your-theme]/tribe-events/day/single-event.php
 *
 * @package TribeEventsCalendar
 * 
 * @cmsmasters_package 	Dream City
 * @cmsmasters_version 	1.0.3
 *
 */


if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}


include(get_template_directory() . '/tribe-events/cmsmasters-framework/theme-style' . CMSMASTERS_THEME_STYLE . '/templates/day/single-event.php');