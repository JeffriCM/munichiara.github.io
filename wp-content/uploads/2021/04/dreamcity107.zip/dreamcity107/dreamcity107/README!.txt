Thank you for using Dream City theme!

We did our best to create a fantastic theme for you, hope you will enjoy using it.

Please make sure you reference theme documentation for installation and usage instructions. Please see the DOCS folder and open index.html file with your browser.

In any case, should there be any questions or anything you need help with, please feel free to contact our support at:
http://cmsmasters.net/support

If you downloaded the theme for the first time, simply install the theme as descrided in theme docs.
To update your theme please replace the theme on your server with the new theme from this archive. We also recommend creating a backup for the old theme before doing this, just in case. Should you need help with installation or updates, please feel free to conact our support. 

To update the theme automatically please use the Envato Market plugin included to the theme archive. You need to install the plugin onto your WordPress site and acticate it. After activating the plugin, click on the “Envato Market” icon from the left sidebar. To generate your Global OAuth Personal Token click on this link: https://build.envato.com/create-token/?purchase:download=t&purchase:verify=t&purchase:list=t and login using your Envato Market login details. Please copy & paste your unique token into the Envato settings inside your WordPress dashboard and click on “Save Changes”. 
Once you have configured this properly, you will see a screen where you can install or update your already purchased plugins & themes.